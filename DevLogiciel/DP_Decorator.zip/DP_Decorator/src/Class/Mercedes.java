package Class;

public class Mercedes extends Voiture{
    public Mercedes() {
        setMarque("Mercedes");
        setPrix(6000);
        setPoids(2000);
    }
}
