package Class;

public class Citroen extends Voiture{
    public Citroen() {
        setMarque("Citroen");
        setPrix(5000);
        setPoids(1000);
    }
}
