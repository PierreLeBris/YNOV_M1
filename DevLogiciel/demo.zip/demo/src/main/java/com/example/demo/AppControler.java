package com.example.demo;

import config.DBConfig;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@RestController
@RequestMapping(path = "/")
public class AppControler {

    @RequestMapping(path = "/hi")
    public String sayHi(){
        DBConfig dbConfig = new DBConfig();
        Connection con = null;
        String firstName = null, lastName = null , password = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            con = dbConfig.getConnection();
            ps = con.prepareStatement("Select * from User where idUser = ?;");
            ps.setInt(1, 1);
            rs = ps.executeQuery();
            if(rs.next()){
                firstName = rs.getString("firstname");
                lastName = rs.getString("lastname");
                password = rs.getString("password");
            }
        }catch (Exception ex){
            System.out.println("Error");
        }finally {
            dbConfig.closeResultSet(rs);
            dbConfig.closePreparedStatement(ps);
            dbConfig.closeConnection(con);
        }
        return firstName;
    }
}
