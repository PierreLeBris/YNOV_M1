package model;

public class Item extends Element{

	public Item() {
		
	}
	public Item(int x, int y, String name, char charForMap) {
		super(x, y, name, charForMap);
	}

}
