package model;

public class Player extends Personnage{

	public Player(int x, int y, String name, char charForMap, int pdv, int pdd) {
		super(x, y, name, charForMap, pdv, pdd);
	}

	

	
}
