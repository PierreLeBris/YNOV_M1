package model;

public class Enemy extends Personnage{

	public Enemy(int x, int y, String name, char charForMap, int pdv, int pdd) {
		super(x, y, name, charForMap, pdv, pdd);
	}
	

}
