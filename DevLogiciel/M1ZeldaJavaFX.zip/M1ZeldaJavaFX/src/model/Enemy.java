package model;

public class Enemy extends Element{

	public Enemy(int x, int y, String name, char charForMap) {
		super(x, y, name, charForMap);
	}
	

}
