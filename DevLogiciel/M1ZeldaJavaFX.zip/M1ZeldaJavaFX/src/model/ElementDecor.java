package model;

public class ElementDecor extends Element{

    public ElementDecor(){

    }

    public ElementDecor(int x, int y, String name, char charForMap)
    {
        super(x, y, name, charForMap);
    }

}
