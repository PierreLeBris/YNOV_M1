package sample;

import javafx.scene.Group;
import javafx.scene.shape.Circle;
import model.Item;

import java.util.HashMap;

public class DataView {

    public static HashMap<Item, Circle> hmItems = new HashMap<Item, Circle>();

    public static Group groupGame = new Group();



}
