package model;

import java.util.ArrayList;

public class Player extends Element{

	
	public Player(int x, int y, String name, char charForMap) {
		super(x, y, name, charForMap);
	}

	

	
}
