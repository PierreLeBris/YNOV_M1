package model;

public class Player extends Perso{

	public Player(int x, int y, char nom) {
		super(x, y, nom);
		// TODO Auto-generated constructor stub
	}

	
	
}
