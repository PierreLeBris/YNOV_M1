package model;

public class Enemy extends Perso{

	public Enemy(int x, int y, char nom) {
		super(x, y, nom);
		// TODO Auto-generated constructor stub
	}

}
