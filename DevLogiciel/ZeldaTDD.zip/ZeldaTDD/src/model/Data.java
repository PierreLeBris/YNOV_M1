package model;

import java.util.ArrayList;

public class Data {

	public char [][] map;
	public ArrayList<Perso> alPerso;
	
	
	public Data() {
		map = new char [20][20];
		alPerso = new ArrayList<Perso>();
	}
	
	
}
