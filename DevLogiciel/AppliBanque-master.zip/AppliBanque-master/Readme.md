V1 Mode console

Gestion de Comptes

Read Compte - details historique Transactions
Controle Transactions create (solde positif...)
Mise en place d'une sécurité (mdp confirmation transaction)

Transactions
entre comptes d'une même personne
entre compte de deux personnes dif
remise, retrait

Persitence : Fichier txt

