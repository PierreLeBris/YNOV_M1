package Controller;

import View.View;

import java.util.Scanner;

public class Main {

    public static void main(String [] args){
        View.printMainMenu();
        Scanner sc = new Scanner(System.in);
        String choice = sc.nextLine();
        switch (choice){

        }
    }
}
