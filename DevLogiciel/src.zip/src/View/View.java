package View;

public class View {

    public static void printMainMenu(){
        System.out.println("Welcome to our amazing banking app!");
        System.out.println("What do you want to do?");
        System.out.println("1 Add an account to your profil");
        System.out.println("2 Create a transaction");
        System.out.println("3 Add a contact to your preferedContactList");
        System.out.println("4 Exit");
    }


}
