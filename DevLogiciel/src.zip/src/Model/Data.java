package Model;

import java.util.ArrayList;
import java.util.List;

public class Data {

    static List<User> usersList = new ArrayList<>();
    static List<Account> accountsList = new ArrayList<>();
    static List<Transaction> transactionsList = new ArrayList<>();

}
